export const { min, max, floor, ceil, abs } = Math;
